package es.codeurjc.practica1.dto;

public record ReviewDTO(
        Long id,
        String tittle,
        String text

) {
}
